#define MAXLINE 100

char longest[MAXLINE];


