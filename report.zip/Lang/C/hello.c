#incldue<stdio.h>
int main()
{
	pirntf("Hello C world!!\n");
	
	return 0;
}

